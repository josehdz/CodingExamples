﻿using System;
using System.Collections.Generic;

namespace FiccBuzzLibrary
{
    /// <summary>
    /// Generates numbers and strings between a given range. 
    /// </summary>
    public class FiccBuzz
    {
        // The default values. Made internal instead of private so unit tests can access constants
        internal const int Divisor3 = 3;
        internal const int Divisor5 = 5;
        internal const string Ficc = "Ficc";
        internal const string Buzz = "Buzz";
        internal const int Min = 1;
        internal const int Max = 100;

        public int Divisor1 { get; set; }
        public int Divisor2 { get; set; }
        public string StringValue1 { get; set; }
        public string StringValue2 { get; set; }
        public Range Range { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public FiccBuzz()
            : this(new Range(1,100))
        {
        }

        /// <summary>
        /// Constructor that takes an initial range
        /// </summary>
        /// <param name="range">The range for the strings to generate</param>
        public FiccBuzz(Range range)
        {
            Range = range;

            Divisor1 = Divisor3;
            Divisor2 = Divisor5;
            StringValue1 = Ficc;
            StringValue2 = Buzz;
        }

        /// <summary>
        /// Constructor that takes a minimum and maximum value for the range
        /// </summary>
        /// <param name="min">The minimum value to generate</param>
        /// <param name="max">The maximum value to generate</param>
        public FiccBuzz(int min, int max) 
            : this(new Range(min, max))
        {
        }

        /// <summary>
        /// Generates the string values
        /// </summary>
        /// <returns>A list of values</returns>
        public IEnumerable<string> GetStringValues()
        {
            if (Range.Min > Range.Max)
            {
                throw new RangeException("Maximum value in specified range is lower than the minimum value: " + Range);
            }

            for (int number = Range.Min; number <= Range.Max; number++)
            {
                if (number % Divisor1 == 0 && number % Divisor2 == 0)
                {
                    yield return StringValue1 + StringValue2;
                }
                else if (number % Divisor1 == 0)
                {
                    yield return StringValue1;
                }
                else if (number % Divisor2 == 0)
                {
                    yield return StringValue2;
                }
                else
                {
                    yield return number.ToString();
                }
            }
        }
    }
}
