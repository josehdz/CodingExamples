﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiccBuzzLibrary
{
    /// <summary>
    /// Range class that has a low and max value
    /// </summary>
    public class Range
    {
        /// <summary>
        /// Constructor that takes a minimum and maximum value of the range
        /// </summary>
        /// <param name="min">The minimum value</param>
        /// <param name="max">The maximum value</param>
        public Range(int min, int max)
        {
            Min = min;
            Max = max;
        }

        public int Min { get; set; }
        public int Max { get; set; }

        public override string ToString()
        {
            return "Minimum = " + Min + ", Maximum = " + Max;
        }
    }
}
