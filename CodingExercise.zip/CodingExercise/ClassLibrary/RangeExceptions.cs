﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FiccBuzzLibrary
{
    /// <summary>
    /// Thrown when maximum value in range is lower than the minimum value
    /// </summary>
    public class RangeException : Exception
    {
        public RangeException(string message)
            : base(message)
        { }
    }
}
