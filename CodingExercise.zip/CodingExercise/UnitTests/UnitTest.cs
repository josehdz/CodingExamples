﻿using System;
using System.Collections.Generic;
using System.Linq;
using FiccBuzzLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTest
{
    [TestClass]
    public class UnitTest
    {
        [TestMethod]
        public void VerifyDefaultRange()
        {
            var ficcBuzz = new FiccBuzz();
            Assert.IsTrue(ficcBuzz.Range.Min == FiccBuzz.Min && ficcBuzz.Range.Max == FiccBuzz.Max, "Default range values are not the expected values of 1 and 100");
        }

        [TestMethod]
        public void VerifyDefaultStrings()
        {
            var ficcBuzz = new FiccBuzz();
            Assert.IsTrue(ficcBuzz.StringValue1 == FiccBuzz.Ficc && ficcBuzz.StringValue2 == FiccBuzz.Buzz, "Default strings are not the expected values of Ficc and Buzz");
        }

        [TestMethod]
        public void VerifyDefaultDivisors()
        {
            var ficcBuzz = new FiccBuzz();
            Assert.IsTrue(ficcBuzz.Divisor1 == FiccBuzz.Divisor3 && ficcBuzz.Divisor2 == FiccBuzz.Divisor5, "Default divisors are not the expected values of 3 and 5");
        }

        [TestMethod]
        public void VerifyNonDefaultConstructors()
        {
            // Ideally, there should be only one assert per test when possible, but sometimes it makes it easier to group tests into one test method for readability
            var ficcBuzz = new FiccBuzz(5, 80);
            Assert.IsTrue(ficcBuzz.Range.Min == 5 && ficcBuzz.Range.Max == 80, "Range values are not the expected values of 5 and 80");

            ficcBuzz = new FiccBuzz(new Range(32,98));
            Assert.IsTrue(ficcBuzz.Range.Min == 32 && ficcBuzz.Range.Max == 98, "Range values are not the expected values of 32 and 98");
        }

        [TestMethod]
        public void VerifySettingStringValues()
        {
            var ficcBuzz = new FiccBuzz() { StringValue1 = "Foo", StringValue2 = "Bar" };
            Assert.IsTrue(ficcBuzz.StringValue1 == "Foo" && ficcBuzz.StringValue2 == "Bar", "String values are not the expected values of Foo and Bar");
        }

        [TestMethod]
        public void VerifySettingDivisors()
        {
            var ficcBuzz = new FiccBuzz() { Divisor1 = 7 , Divisor2 = 9 };
            Assert.IsTrue(ficcBuzz.Divisor1 == 7 && ficcBuzz.Divisor2 == 9, "Divisor values are not the expected values of 7 and 9");
        }

        [TestMethod]
        public void VerifySettingRanges()
        {
            var ficcBuzz = new FiccBuzz() { Range = new Range(11, 44) };
            Assert.IsTrue(ficcBuzz.Range.Min == 11 && ficcBuzz.Range.Max == 44, "Range values are not the expected values of 11 and 44");

            ficcBuzz.Range.Min = 22;
            Assert.IsTrue(ficcBuzz.Range.Min == 22 && ficcBuzz.Range.Max == 44, "Range values are not the expected values of 22 and 44");

            ficcBuzz.Range.Max = 55;
            Assert.IsTrue(ficcBuzz.Range.Min == 22 && ficcBuzz.Range.Max == 55, "Range values are not the expected values of 22 and 55");
        }

        [TestMethod]
        [ExpectedException(typeof(RangeException))]
        public void GenerateRangeException()
        {
            var ficcBuzz = new FiccBuzz(55, 11);
            foreach (var value in ficcBuzz.GetStringValues())
            {
                // Do something just to generate exception
                var toLower = value.ToLower();
            }
        }

        [TestMethod]
        public void VerifyValuesWhenDivisibleByDivisor1()
        {
            VerifyValuesWhenDivisibleByDivisor1Only(new FiccBuzz());

            var ficcBuzz = new FiccBuzz { StringValue1 = "Foo", StringValue2 = "Bar" };
            VerifyValuesWhenDivisibleByDivisor1Only(ficcBuzz);

            ficcBuzz = new FiccBuzz { Divisor1 = 5, Divisor2 = 7 };
            VerifyValuesWhenDivisibleByDivisor1Only(ficcBuzz);

            ficcBuzz = new FiccBuzz(35, 180) { Divisor1 = 5, Divisor2 = 7 };
            VerifyValuesWhenDivisibleByDivisor1Only(ficcBuzz);

            ficcBuzz = new FiccBuzz(35, 180) { Divisor1 = 3, Divisor2 = 7, StringValue1 = "FooBar" };
            VerifyValuesWhenDivisibleByDivisor1Only(ficcBuzz);
        }

        [TestMethod]
        public void VerifyValuesWhenDivisibleByDivisor2()
        {
            VerifyValuesWhenDivisibleByDivisor2Only(new FiccBuzz());

            var ficcBuzz = new FiccBuzz { StringValue1 = "Foo", StringValue2 = "Bar" };
            VerifyValuesWhenDivisibleByDivisor2Only(ficcBuzz);

            ficcBuzz = new FiccBuzz { Divisor1 = 5, Divisor2 = 7 };
            VerifyValuesWhenDivisibleByDivisor2Only(ficcBuzz);

            ficcBuzz = new FiccBuzz(35, 180) { Divisor1 = 5, Divisor2 = 7 };
            VerifyValuesWhenDivisibleByDivisor2Only(ficcBuzz);

            ficcBuzz = new FiccBuzz(35, 180) { Divisor1 = 3, Divisor2 = 7, StringValue1 = "FooBar" };
            VerifyValuesWhenDivisibleByDivisor2Only(ficcBuzz);
        }

        [TestMethod]
        public void VerifyValuesWhenDivisibleByBothDivisors()
        {
            VerifyValuesWhenDivisibleByBothDivisors(new FiccBuzz());

            var ficcBuzz = new FiccBuzz { StringValue1 = "Foo", StringValue2 = "Bar" };
            VerifyValuesWhenDivisibleByBothDivisors(ficcBuzz);

            ficcBuzz = new FiccBuzz { Divisor1 = 5, Divisor2 = 7 };
            VerifyValuesWhenDivisibleByBothDivisors(ficcBuzz);

            ficcBuzz = new FiccBuzz(35, 180) { Divisor1 = 5, Divisor2 = 7 };
            VerifyValuesWhenDivisibleByBothDivisors(ficcBuzz);

            ficcBuzz = new FiccBuzz(35, 180) { Divisor1 = 3, Divisor2 = 7, StringValue1 = "FooBar" };
            VerifyValuesWhenDivisibleByBothDivisors(ficcBuzz);
        }

        private void VerifyValuesWhenDivisibleByDivisor1Only(FiccBuzz ficcBuzz)
        {
            // To simplify testing, lets create a list to iterate
            var list = ficcBuzz.GetStringValues().ToList();
            for (int i = ficcBuzz.Range.Min; i <= ficcBuzz.Range.Max; i++)
            {
                if (i % ficcBuzz.Divisor1 == 0 && i % ficcBuzz.Divisor2 != 0)
                {
                    Assert.IsTrue(list[i - ficcBuzz.Range.Min] == ficcBuzz.StringValue1);
                }
            }
        }

        private void VerifyValuesWhenDivisibleByDivisor2Only(FiccBuzz ficcBuzz)
        {
            // To simplify testing, lets create a list to iterate
            var list = ficcBuzz.GetStringValues().ToList();
            for (int i = ficcBuzz.Range.Min; i <= ficcBuzz.Range.Max; i++)
            {
                if (i % ficcBuzz.Divisor1 != 0 && i % ficcBuzz.Divisor2 == 0)
                {
                    Assert.IsTrue(list[i - ficcBuzz.Range.Min] == ficcBuzz.StringValue2);
                }
            }
        }

        private void VerifyValuesWhenDivisibleByBothDivisors(FiccBuzz ficcBuzz)
        {
            // To simplify testing, lets create a list to iterate
            var list = ficcBuzz.GetStringValues().ToList();
            for (int i = ficcBuzz.Range.Min; i <= ficcBuzz.Range.Max; i++)
            {
                if (i % ficcBuzz.Divisor1 == 0 && i % ficcBuzz.Divisor2 == 0)
                {
                    Assert.IsTrue(list[i - ficcBuzz.Range.Min] == ficcBuzz.StringValue1 + ficcBuzz.StringValue2);
                }
            }
        }
    }
}
