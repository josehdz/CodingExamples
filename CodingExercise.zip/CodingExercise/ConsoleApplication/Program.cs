﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FiccBuzzLibrary;

namespace ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            var ficcBuzz = new FiccBuzz(35, 99);

            foreach (var str in ficcBuzz.GetStringValues())
            {
                Console.WriteLine(str);
            }

            Console.WriteLine();

            try
            {
                ficcBuzz.Range.Max = 5;
                foreach (var str in ficcBuzz.GetStringValues())
                {
                    Console.WriteLine(str);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
